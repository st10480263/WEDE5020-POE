document.addEventListener('DOMContentLoaded', () => {
    const filterSelect = document.getElementById('category-filter');
    const productGrid = document.getElementById('productGrid');
    const productCards = productGrid.querySelectorAll('.product-card');

    if (filterSelect) {
        filterSelect.addEventListener('change', (event) => {
            const selectedCategory = event.target.value;
            
            productCards.forEach(card => {
                const cardCategory = card.getAttribute('data-category');
                
                // Check if the card matches the selected filter

                if (selectedCategory === 'all' || cardCategory === selectedCategory) {

                    // Show the card

                    card.classList.remove('hidden');
                } else {

                    // Hide the card
                    
                    card.classList.add('hidden');
                }
            });
        });
    }
});