document.addEventListener('DOMContentLoaded', () => {
  
    const cartCountElement = document.getElementById('cartCount');
    const cartModal = document.getElementById('cartModal');
    const openCartBtn = document.getElementById('openCartBtn');
    const closeCartBtn = document.getElementById('closeCartBtn');
    const cartItemsContainer = document.getElementById('cartItemsContainer');
    const cartTotalElement = document.getElementById('cartTotal');
    const addToCartButtons = document.querySelectorAll('.add-to-cart-btn');


    let cart = [];

    function saveCart() {
        localStorage.setItem('saintsClothingCart', JSON.stringify(cart));
    }

    function loadCart() {
        const storedCart = localStorage.getItem('saintsClothingCart');
        if (storedCart) {
            cart = JSON.parse(storedCart);
        }
        updateCartDisplay();
    }

    // --- 3. Cart Logic Functions ---

    function addToCart(productId, name, price) {
        const existingItem = cart.find(item => item.id === productId);

        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({ id: productId, name: name, price: parseFloat(price), quantity: 1 });
        }

        saveCart();
        updateCartDisplay();
        showCartNotification(name);
    }

    function removeFromCart(productId) {

        // Filter out the item to be removed

        cart = cart.filter(item => item.id !== productId); 
        
        saveCart();
        updateCartDisplay();
    }

  

    function updateCartDisplay() {

        // Update the count in the header

        const totalItems = cart.reduce((total, item) => total + item.quantity, 0);
        cartCountElement.textContent = totalItems;

        // Clear the modal content

        cartItemsContainer.innerHTML = '';
        let total = 0;

        if (cart.length === 0) {
            cartItemsContainer.innerHTML = '<p style="text-align: center;">Your cart is empty.</p>';
        } else {
            cart.forEach(item => {
                const itemTotal = item.price * item.quantity;
                total += itemTotal;

                const itemHtml = `
                    <div class="cart-item">
                        <span>${item.name} x${item.quantity}</span>
                        <span>
                            £${itemTotal.toFixed(2)} 
                            <button class="remove-btn" data-id="${item.id}">Remove</button>
                        </span>
                    </div>
                `;
                cartItemsContainer.innerHTML += itemHtml;
            });
        }
        
        // Update the total

        cartTotalElement.textContent = `Total: £${total.toFixed(2)}`;

   
        cartItemsContainer.querySelectorAll('.remove-btn').forEach(button => {
            button.addEventListener('click', (e) => {
                removeFromCart(e.target.dataset.id);
            });
        });
    }

    function showCartNotification(productName) {

        // Simple visual feedback: Flash the cart count element

        cartCountElement.style.transition = 'none';
        cartCountElement.style.backgroundColor = 'green';
        cartCountElement.style.color = 'white';
        
        // Reset after a short delay

        setTimeout(() => {
            cartCountElement.style.transition = 'background-color 0.5s, color 0.5s';
            cartCountElement.style.backgroundColor = '#d1b3ff';
            cartCountElement.style.color = '#2e003e';
        }, 300);
    }

    // Listen for clicks on all "Add to Cart" buttons

    addToCartButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            const productCard = e.target.closest('.product-card');
            const id = productCard.dataset.id;
            const name = productCard.dataset.name;
            const price = productCard.dataset.price;
            
            addToCart(id, name, price);
        });
    });

  
    openCartBtn.addEventListener('click', () => {
        cartModal.classList.add('open');

        // Re-render cart content just in case

        updateCartDisplay(); 
    });

    closeCartBtn.addEventListener('click', () => {
        cartModal.classList.remove('open');
    });


    document.addEventListener('click', (e) => {
        if (cartModal.classList.contains('open') && !cartModal.contains(e.target) && !openCartBtn.contains(e.target)) {
            // Note: This needs refinement to exclude children of openCartBtn
            // For now, let's rely on the close button
        }
    });


    loadCart();
});