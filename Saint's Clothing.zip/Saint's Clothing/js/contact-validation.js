document.addEventListener('DOMContentLoaded', () => {

    const form = document.getElementById('contactForm');
    const formStatus = document.getElementById('formStatus');


    function validateField(inputElement) {
        const value = inputElement.value.trim();
        const id = inputElement.id;
        const errorElement = document.getElementById(id + 'Error');
        let isValid = true;
        let errorMessage = '';

        // Clear previous error message

        errorElement.textContent = '';
        inputElement.style.borderColor = '#ddd';

        if (inputElement.hasAttribute('required') && value === '') {
            isValid = false;
            errorMessage = `${id.charAt(0).toUpperCase() + id.slice(1)} is required.`;
        } else if (id === 'email') {
  

            if (value !== '' && !emailRegex.test(value)) {
                isValid = false;
                errorMessage = 'Please enter a valid email address.';
            }
        } else if (id === 'name' && value.length < 2) {
             isValid = false;
             errorMessage = 'Name must be at least 2 characters long.';
        } else if (id === 'message' && value.length < 10) {
             isValid = false;
             errorMessage = 'Message must be at least 10 characters long.';
        } else if (id === 'phone' && value !== '') {
           
 
            if (!phoneRegex.test(value)) {
                isValid = false;
                errorMessage = 'Please enter a valid phone number format.';
            }
        } else if (id === 'type' && value === '') {
             isValid = false;
             errorMessage = 'Please select a message type.';
        }

        // Display error if invalid

        if (!isValid) {
            errorElement.textContent = errorMessage;
            inputElement.style.borderColor = 'red';
        }

        return isValid;
    }


    function validateForm() {
        let isFormValid = true;
        const requiredInputs = form.querySelectorAll('input[required], select[required], textarea[required]');
        
        requiredInputs.forEach(input => {

            if (!validateField(input)) {
                isFormValid = false;
            }
        });

        const phoneInput = document.getElementById('phone');
        if (phoneInput && phoneInput.value.trim() !== '') {
            if (!validateField(phoneInput)) {
                isFormValid = false;
            }
        }
        
        return isFormValid;
    }

    const allInputs = form.querySelectorAll('input, select, textarea');
    allInputs.forEach(input => {
        input.addEventListener('blur', () => {
            validateField(input);
        });
    });

    form.addEventListener('submit', function(event) {
        event.preventDefault(); 
        formStatus.textContent = ''; 

        if (validateForm()) {
      
            formStatus.style.color = 'orange';
            formStatus.textContent = 'Sending message...';

            const formData = new FormData(form);
            const actionUrl = form.getAttribute('action');

            fetch(actionUrl, {
                method: 'POST',
                body: formData,
                
            })
            .then(response => {
                
                if (response.ok) {
                    return response.text(); 
                }
                throw new Error('Network response was not ok.');
            })
            .then(data => {
             
                formStatus.style.color = 'green';
   
                formStatus.textContent = '✅ Message sent successfully! We will be in touch soon.';
                form.reset(); 
            })
            .catch(error => {
              
                console.error('Submission Error:', error);
                formStatus.style.color = 'red';
                formStatus.textContent = '❌ Submission failed. Please try again later.';
            });
        } else {
           
            formStatus.style.color = 'red';
            formStatus.textContent = '❌ Please correct the errors in the form.';
        }
    });
});