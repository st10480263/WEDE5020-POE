document.addEventListener('DOMContentLoaded', () => {
   
    const headers = document.querySelectorAll('.accordion-header');

    // Function to close a single accordion item
    function closeItem(header, content) {
        header.classList.remove('active');
        content.classList.remove('active');
        content.style.maxHeight = '0'; 
    }


    function closeAllAccordions(excludeHeader = null) {
        headers.forEach(header => {
            header.addEventListener('click', () => {
                const content = header.nextElementSibling;
                
                // Check if already open

                const isCurrentlyOpen = content.classList.contains('active');
    
                // Close all others

                closeAllAccordions(header); 
                
                if (!isCurrentlyOpen) {

                    // OPEN LOGIC

                    header.classList.add('active');
                    content.classList.add('active');
                    
                    content.style.maxHeight = content.scrollHeight + 100 + "px"; 
                } else {

                    // CLOSE LOGIC

                    closeItem(header, content);
                }
            });
        });
    }

    headers.forEach(header => {
        header.addEventListener('click', () => {
            const content = header.nextElementSibling;
            
            // Check if the current panel is already open

            const isCurrentlyOpen = content.classList.contains('active');

            // 1. Close all other open accordion items

            closeAllAccordions(header); 
            
            // 2. If the item was NOT currently open, open it

            if (!isCurrentlyOpen) {
                // Add active classes
                header.classList.add('active');
                content.classList.add('active');
                

                content.style.maxHeight = content.scrollHeight + 50 + "px";
            } else {

                closeItem(header, content);
            }
        });
    });
});